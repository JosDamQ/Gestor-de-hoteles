'use strict'

const Bill = require('./bill.model')
const {validateData} = require('../utils/validate')
const User = require('../user/user.model')

exports.test = (req, res)=>{
  return res.send({message: 'Bill test running'});
}

exports.createReservation = async(req, res)=>{
  try {
    
  } catch (err) {
    console.log(err);
  }
}

exports.createEvent = async(req, res)=>{
  try {
    
  } catch (err) {
    console.log(err);
  }
}